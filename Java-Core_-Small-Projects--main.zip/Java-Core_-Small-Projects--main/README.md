Java SE projects
